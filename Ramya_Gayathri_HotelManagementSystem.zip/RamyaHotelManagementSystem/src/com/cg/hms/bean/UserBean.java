package com.cg.hms.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="users")
@NamedQuery(name="loginquery",query="select u from UserBean u where u.userName=:user and u.password=:pass")
public class UserBean 
{
	@Id
	@Column(name="user_id")
	@GeneratedValue
	private int userId;
		@Column(name="password")
	private String password;
		@Column(name="role")
	private String role;
		@Column(name="user_name")
	private String userName;
		@Column(name="mobile_no")
	private String mobile;
		@Column(name="phone")
	private String phone;
		@Column(name="address")
	private String address;
		@Column(name="email")
	private String email;
	
	/******************************************************************************************************************
                                          Getters&Setters
    ********************************************************************************************************************/
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	/******************************************************************************************************************
                          Parameterized constructor
    ********************************************************************************************************************/
	
	  public UserBean(String password, String role, String userName,
			String mobile, String phone, String address, String email) {
		super();
		this.password = password;
		this.role = role;
		this.userName = userName;
		this.mobile = mobile;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}

	public String getUserName() {
	    return userName;
	  }

	  public void setUserName(String userName) {
	    this.userName = userName;
	  }

	  public String getPassword() {
	    return password;
	  }

	  public void setPassword(String password) {
	    this.password = password;
	  }

	public UserBean(int userId, String password, String role, String userName,
			String mobile, String phone, String address, String email) {
		super();
		this.userId = userId;
		this.password = password;
		this.role = role;
		this.userName = userName;
		this.mobile = mobile;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	
	/******************************************************************************************************************
                                     Default constructor
    ********************************************************************************************************************/
	public UserBean() {
		super();
	}

	@Override
	public String toString() {
		return "UserBean [userId=" + userId + ", password=" + password
				+ ", role=" + role + ", userName=" + userName
				+ ", mobile=" + mobile + ", phone=" + phone
				+ ", address=" + address + ", email=" + email + "]";
	}
	  
}
